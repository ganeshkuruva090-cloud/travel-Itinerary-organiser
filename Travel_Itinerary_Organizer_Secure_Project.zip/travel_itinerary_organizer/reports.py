import csv
from datetime import datetime

FIELDS = ["destination", "start_date", "end_date", "category", "status", "cost", "notes"]

def safe_csv_cell(value):
    """Prevent spreadsheet formula execution when exported and opened in spreadsheet apps."""
    s = str(value)
    if s.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")):
        return "'" + s
    return s

def export_csv(trips, path):
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for trip in trips:
            writer.writerow({k: safe_csv_cell(trip.get(k, "")) for k in FIELDS})

def export_markdown(trips, path):
    total = sum(float(t.get("cost", 0)) for t in trips if t.get("status") != "Cancelled")
    lines = ["# Travel Itinerary Report", "", f"Generated: {datetime.now():%Y-%m-%d %H:%M}",
             f"Trips: {len(trips)}", f"Estimated active budget: ₹{total:,.2f}", "",
             "| Destination | Dates | Category | Status | Cost (INR) |",
             "|---|---|---|---|---:|"]
    for t in trips:
        lines.append(f"| {t['destination'].replace('|','/')} | {t['start_date']} – {t['end_date']} | {t['category']} | {t['status']} | {t['cost']:.2f} |")
    open(path, "w", encoding="utf-8").write("\n".join(lines))

def export_text(trips, path):
    total = sum(float(t.get("cost", 0)) for t in trips if t.get("status") != "Cancelled")
    lines = ["TRAVEL ITINERARY ORGANIZER - SUMMARY",
             f"Generated: {datetime.now():%Y-%m-%d %H:%M}",
             f"Total records: {len(trips)}",
             f"Estimated active budget: INR {total:,.2f}", ""]
    for i, t in enumerate(trips, 1):
        lines += [f"{i}. {t['destination']} ({t['start_date']} to {t['end_date']})",
                  f"   {t['category']} | {t['status']} | INR {t['cost']:.2f}",
                  f"   Notes: {t['notes']}", ""]
    open(path, "w", encoding="utf-8").write("\n".join(lines))
