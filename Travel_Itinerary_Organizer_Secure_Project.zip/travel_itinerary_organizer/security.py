import base64
import hashlib
import json
import os
import tempfile
from pathlib import Path

try:
    from cryptography.fernet import Fernet, InvalidToken
except ImportError:
    Fernet = None
    InvalidToken = Exception

class SecurityError(Exception):
    pass

class Vault:
    """Encrypted local vault. Password-derived Fernet key; never stores password."""
    def __init__(self, path, password):
        if Fernet is None:
            raise SecurityError("Missing dependency. Run: pip install -r requirements.txt")
        if len(password) < 12:
            raise SecurityError("Use a master password with at least 12 characters.")
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.meta = self.path.with_suffix(".meta")
        if self.meta.exists():
            try:
                meta = json.loads(self.meta.read_text(encoding="utf-8"))
                salt = base64.b64decode(meta["salt"])
                iterations = int(meta["iterations"])
            except Exception:
                raise SecurityError("Vault metadata is damaged. Restore a trusted backup.")
        else:
            if self.path.exists():
                raise SecurityError("Vault metadata is missing. Restore a trusted backup.")
            salt = os.urandom(16)
            iterations = 600_000
            key = self._derive(password, salt, iterations)
            self._write_meta({"salt": base64.b64encode(salt).decode(), "iterations": iterations})
            self._key = key
            self._fernet = Fernet(key)
            self.save([])
            return
        key = self._derive(password, salt, iterations)
        self._key = key
        self._fernet = Fernet(key)
        if self.path.exists():
            try:
                self._fernet.decrypt(self.path.read_bytes())
            except InvalidToken:
                raise SecurityError("Incorrect password or encrypted vault is damaged.")
        else:
            self.save([])

    @staticmethod
    def _derive(password, salt, iterations):
        raw = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations, dklen=32)
        return base64.urlsafe_b64encode(raw)

    def _write_meta(self, obj):
        self._atomic_write(self.meta, json.dumps(obj).encode("utf-8"))

    @staticmethod
    def _atomic_write(path, data):
        path = Path(path)
        fd, tmp = tempfile.mkstemp(prefix=".secure-", dir=str(path.parent))
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, path)
            try: os.chmod(path, 0o600)
            except OSError: pass
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

    def load(self):
        if not self.path.exists():
            return []
        try:
            raw = self._fernet.decrypt(self.path.read_bytes())
            data = json.loads(raw.decode("utf-8"))
            if not isinstance(data, list):
                raise ValueError("Vault root must be a list.")
            return data
        except Exception:
            raise SecurityError("Could not safely read the vault. No data was overwritten.")

    def save(self, trips):
        try:
            payload = json.dumps(trips, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            encrypted = self._fernet.encrypt(payload)
            self._atomic_write(self.path, encrypted)
        except Exception as e:
            raise SecurityError("Secure save failed; existing vault was preserved.") from e
