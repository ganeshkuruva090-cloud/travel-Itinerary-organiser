# VOYAGE — Travel Itinerary Organizer

A polished Python desktop application built from the StudentLife Hack Project #52 brief.

## Features
- Password-protected workspace (PBKDF2-HMAC-SHA256, 600,000 iterations)
- Authenticated encryption of the complete local trip vault (Fernet)
- Atomic encrypted saves and encrypted backup copies
- Menu-driven terminal interface plus enhanced Tkinter GUI
- Add, edit, delete, search and status-filter trips
- Strict destination, date, duration, cost, category and status validation
- Dashboard metrics and estimated budget aggregation
- CSV, Markdown and plain-text report export
- Bulk CSV import with row-by-row validation errors
- CSV formula-injection mitigation
- Security event audit log (does not record passwords or trip notes)
- Graceful handling of missing, damaged or inaccessible vault files

## Requirements
- Python 3.10+
- Tkinter (usually included with standard Python on Windows)
- `cryptography`

Install:
```bash
python -m pip install -r requirements.txt
```

Run the enhanced desktop GUI:
```bash
python app.py
```

Or run the PDF-required interactive terminal menu:
```bash
python cli.py
```

On first launch, create a strong master password (12+ characters). Use a unique password and keep it safe. The application does not provide password recovery: losing the password means the encrypted vault cannot be decrypted.

## Storage
- `data/trips.vault`: encrypted trip records
- `data/trips.meta`: random salt and PBKDF2 settings (not the password)
- `data/audit.log`: minimal security event log
- `backups/`: encrypted vault backups
- `exports/`: exported reports

The password-derived encryption key is held only in application memory while the application is running. The master password is not written to disk.

## Security notes
- Fernet provides authenticated encryption; do not replace it with custom cryptography.
- File permission restrictions are best-effort and depend on the operating system.
- Exported reports are intentionally readable and are not encrypted. Store and share them carefully.
- The audit log records event types and timestamps, not sensitive trip details.
- This is a local desktop application, not a centrally managed multi-user service. Keep the device account protected and maintain offline backups.

## Demo checklist (aligned with the PDF)
1. Launch the app and create a master password.
2. Add a trip with an invalid date or negative cost; show validation rejecting it.
3. Add two valid trips and show the dashboard totals.
4. Search for a destination and filter by status.
5. Edit and delete a selected trip.
6. Export CSV and Markdown reports.
7. Close and reopen the app using the same password to demonstrate persistence.
8. Attempt an incorrect password to demonstrate encrypted vault protection.
9. Create an encrypted backup.

## Project structure
```text
travel_itinerary_organizer/
├── app.py
├── security.py
├── reports.py
├── requirements.txt
├── README.md
├── data/
├── backups/
└── exports/
```
