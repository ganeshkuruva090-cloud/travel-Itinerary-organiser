import csv
import json
import os
import re
import shutil
import tempfile
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import date, datetime
from pathlib import Path

from security import Vault, SecurityError
from reports import export_csv, export_markdown, export_text

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
BACKUP_DIR = APP_DIR / "backups"
EXPORT_DIR = APP_DIR / "exports"
VAULT_PATH = DATA_DIR / "trips.vault"
AUDIT_PATH = DATA_DIR / "audit.log"

BG = "#0b1220"
PANEL = "#121d30"
PANEL2 = "#18263d"
TEXT = "#edf4ff"
MUTED = "#91a4c0"
ACCENT = "#42a5f5"
GREEN = "#31c48d"
RED = "#ff647c"

def audit(event):
    DATA_DIR.mkdir(exist_ok=True)
    line = f"{datetime.now().isoformat(timespec='seconds')} | {event}\n"
    with AUDIT_PATH.open("a", encoding="utf-8") as f:
        f.write(line)
    try:
        os.chmod(AUDIT_PATH, 0o600)
    except OSError:
        pass

def validate_trip(data, existing_id=None, trips=None):
    required = ["destination", "start_date", "end_date", "notes", "cost", "category", "status"]
    for key in required:
        if key not in data:
            raise ValueError(f"Missing field: {key}")
    destination = data["destination"].strip()
    if not destination or len(destination) > 80:
        raise ValueError("Destination must contain 1–80 characters.")
    if any(ord(c) < 32 for c in destination):
        raise ValueError("Destination contains unsupported control characters.")
    try:
        start = date.fromisoformat(data["start_date"])
        end = date.fromisoformat(data["end_date"])
    except ValueError:
        raise ValueError("Dates must use YYYY-MM-DD format.")
    if end < start:
        raise ValueError("End date cannot be earlier than start date.")
    if (end - start).days > 730:
        raise ValueError("A trip cannot exceed two years.")
    try:
        cost = float(data["cost"])
    except (TypeError, ValueError):
        raise ValueError("Estimated cost must be a number.")
    if not (0 <= cost <= 100000000):
        raise ValueError("Cost must be between 0 and 100,000,000.")
    if len(data["notes"]) > 2000:
        raise ValueError("Notes cannot exceed 2,000 characters.")
    if data["category"] not in ("Leisure", "Business", "Education", "Family", "Adventure", "Other"):
        raise ValueError("Choose a valid category.")
    if data["status"] not in ("Planned", "Ongoing", "Completed", "Cancelled"):
        raise ValueError("Choose a valid status.")
    return {
        "id": existing_id or datetime.now().strftime("%Y%m%d%H%M%S%f"),
        "destination": destination,
        "start_date": start.isoformat(),
        "end_date": end.isoformat(),
        "notes": data["notes"].strip(),
        "cost": round(cost, 2),
        "category": data["category"],
        "status": data["status"],
        "created_at": data.get("created_at", datetime.now().isoformat(timespec="seconds")),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }

class TravelApp:
    def __init__(self, root, vault):
        self.root, self.vault = root, vault
        self.trips = vault.load()
        self.selected_id = None
        self.root.title("Voyage | Travel Itinerary Organizer")
        self.root.geometry("1180x760")
        self.root.minsize(980, 650)
        self.root.configure(bg=BG)
        self.style()
        self.build()
        self.refresh()

    def style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=TEXT,
                    rowheight=34, borderwidth=0, font=("Segoe UI", 10))
        s.configure("Treeview.Heading", background=PANEL2, foreground=TEXT,
                    font=("Segoe UI", 10, "bold"), relief="flat")
        s.map("Treeview", background=[("selected", "#244d78")], foreground=[("selected", "white")])
        s.configure("TCombobox", fieldbackground=PANEL2, background=PANEL2, foreground=TEXT)
        s.configure("TEntry", fieldbackground=PANEL2, foreground=TEXT)

    def label(self, parent, text, size=10, color=TEXT, weight="normal"):
        return tk.Label(parent, text=text, bg=parent.cget("bg"), fg=color,
                        font=("Segoe UI", size, weight))

    def button(self, parent, text, command, color=ACCENT):
        return tk.Button(parent, text=text, command=command, bg=color, fg="#07111f",
                         activebackground=color, activeforeground="#07111f",
                         relief="flat", bd=0, padx=15, pady=9,
                         font=("Segoe UI", 10, "bold"), cursor="hand2")

    def build(self):
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=24, pady=(20, 12))
        tk.Label(header, text="✈  VOYAGE", bg=BG, fg=TEXT,
                 font=("Segoe UI", 22, "bold")).pack(side="left")
        tk.Label(header, text="TRAVEL ITINERARY ORGANIZER", bg=BG, fg=MUTED,
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=15, pady=(10, 0))
        self.button(header, "＋  Add trip", self.clear_form).pack(side="right")

        self.stats = tk.Frame(self.root, bg=BG)
        self.stats.pack(fill="x", padx=24, pady=8)

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=24, pady=12)
        left = tk.Frame(body, bg=PANEL, width=340)
        left.pack(side="left", fill="y", padx=(0, 14))
        left.pack_propagate(False)
        tk.Label(left, text="TRIP DETAILS", bg=PANEL, fg=ACCENT,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=18, pady=(18, 12))

        self.vars = {k: tk.StringVar() for k in ("destination", "start_date", "end_date", "cost", "category", "status")}
        self.vars["category"].set("Leisure")
        self.vars["status"].set("Planned")
        self.field(left, "Destination", "destination", "e.g. Hyderabad")
        self.field(left, "Start date (YYYY-MM-DD)", "start_date", date.today().isoformat())
        self.field(left, "End date (YYYY-MM-DD)", "end_date", date.today().isoformat())
        self.field(left, "Estimated cost (INR)", "cost", "0.00")
        self.label(left, "Category", 9, MUTED, "bold").pack(anchor="w", padx=18, pady=(9, 3))
        ttk.Combobox(left, textvariable=self.vars["category"], state="readonly",
                     values=["Leisure", "Business", "Education", "Family", "Adventure", "Other"]).pack(fill="x", padx=18)
        self.label(left, "Status", 9, MUTED, "bold").pack(anchor="w", padx=18, pady=(9, 3))
        ttk.Combobox(left, textvariable=self.vars["status"], state="readonly",
                     values=["Planned", "Ongoing", "Completed", "Cancelled"]).pack(fill="x", padx=18)
        self.label(left, "Notes", 9, MUTED, "bold").pack(anchor="w", padx=18, pady=(9, 3))
        self.notes = tk.Text(left, height=4, bg=PANEL2, fg=TEXT, insertbackground=TEXT,
                             relief="flat", wrap="word", font=("Segoe UI", 10))
        self.notes.pack(fill="x", padx=18)
        actions = tk.Frame(left, bg=PANEL)
        actions.pack(fill="x", padx=18, pady=14)
        self.button(actions, "Save trip", self.save_trip).pack(side="left")
        self.button(actions, "Clear", self.clear_form, "#b8c7da").pack(side="left", padx=8)
        self.button(left, "Delete selected", self.delete_trip, RED).pack(anchor="w", padx=18, pady=(0, 12))

        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)
        top = tk.Frame(right, bg=BG)
        top.pack(fill="x", pady=(0, 12))
        self.search_var = tk.StringVar()
        search = tk.Entry(top, textvariable=self.search_var, bg=PANEL, fg=TEXT,
                          insertbackground=TEXT, relief="flat", font=("Segoe UI", 11))
        search.pack(side="left", fill="x", expand=True, ipady=10, padx=(0, 8))
        search.insert(0, "")
        search.bind("<KeyRelease>", lambda e: self.refresh())
        self.filter_var = tk.StringVar(value="All")
        ttk.Combobox(top, textvariable=self.filter_var, state="readonly", width=14,
                     values=["All", "Planned", "Ongoing", "Completed", "Cancelled"]).pack(side="left")
        self.filter_var.trace_add("write", lambda *_: self.refresh())
        self.button(top, "↻", self.refresh).pack(side="left", padx=8)

        table_wrap = tk.Frame(right, bg=PANEL)
        table_wrap.pack(fill="both", expand=True)
        cols = ("destination", "dates", "category", "status", "cost")
        self.tree = ttk.Treeview(table_wrap, columns=cols, show="headings", selectmode="browse")
        for c, title, width in [("destination", "DESTINATION", 180), ("dates", "TRAVEL DATES", 190),
                                ("category", "CATEGORY", 120), ("status", "STATUS", 110), ("cost", "EST. COST (₹)", 120)]:
            self.tree.heading(c, text=title)
            self.tree.column(c, width=width, anchor="w")
        self.tree.pack(fill="both", expand=True, padx=8, pady=8)
        self.tree.bind("<<TreeviewSelect>>", self.select_trip)

        bottom = tk.Frame(right, bg=BG)
        bottom.pack(fill="x", pady=12)
        self.button(bottom, "Export CSV", lambda: self.export("csv"), GREEN).pack(side="left")
        self.button(bottom, "Export Markdown", lambda: self.export("md")).pack(side="left", padx=8)
        self.button(bottom, "Export text report", lambda: self.export("txt")).pack(side="left")
        self.button(bottom, "Encrypted backup", self.backup, "#b8c7da").pack(side="right")

    def field(self, parent, title, key, placeholder=""):
        self.label(parent, title, 9, MUTED, "bold").pack(anchor="w", padx=18, pady=(7, 3))
        e = tk.Entry(parent, textvariable=self.vars[key], bg=PANEL2, fg=TEXT,
                     insertbackground=TEXT, relief="flat", font=("Segoe UI", 10))
        e.pack(fill="x", padx=18, ipady=8)
        if placeholder and not self.vars[key].get():
            e.insert(0, placeholder) if key == "destination" else None

    def stat_card(self, parent, title, value, color):
        card = tk.Frame(parent, bg=PANEL, padx=18, pady=13)
        card.pack(side="left", fill="x", expand=True, padx=(0, 10))
        tk.Label(card, text=title.upper(), bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w")
        tk.Label(card, text=value, bg=PANEL, fg=color,
                 font=("Segoe UI", 19, "bold")).pack(anchor="w", pady=(4, 0))

    def refresh(self):
        for w in self.stats.winfo_children(): w.destroy()
        active = [t for t in self.trips if t["status"] != "Cancelled"]
        total_cost = sum(t["cost"] for t in active)
        self.stat_card(self.stats, "Total trips", str(len(self.trips)), ACCENT)
        self.stat_card(self.stats, "Upcoming / active", str(sum(t["status"] in ("Planned", "Ongoing") for t in self.trips)), GREEN)
        self.stat_card(self.stats, "Estimated budget", f"₹{total_cost:,.2f}", "#f6c85f")
        for item in self.tree.get_children(): self.tree.delete(item)
        q = self.search_var.get().strip().lower()
        status = self.filter_var.get()
        for t in sorted(self.trips, key=lambda x: x["start_date"]):
            hay = " ".join(str(t[k]) for k in ("destination", "notes", "category", "status")).lower()
            if q and q not in hay: continue
            if status != "All" and t["status"] != status: continue
            self.tree.insert("", "end", iid=t["id"], values=(
                t["destination"], f'{t["start_date"]} → {t["end_date"]}',
                t["category"], t["status"], f'{t["cost"]:,.2f}'
            ))

    def clear_form(self):
        self.selected_id = None
        for k in self.vars: self.vars[k].set("")
        self.vars["start_date"].set(date.today().isoformat())
        self.vars["end_date"].set(date.today().isoformat())
        self.vars["cost"].set("0.00")
        self.vars["category"].set("Leisure")
        self.vars["status"].set("Planned")
        self.notes.delete("1.0", "end")
        self.tree.selection_remove(self.tree.selection())

    def save_trip(self):
        data = {k: v.get() for k, v in self.vars.items()}
        data["notes"] = self.notes.get("1.0", "end").strip()
        try:
            record = validate_trip(data, self.selected_id, self.trips)
            if self.selected_id:
                old = next(t for t in self.trips if t["id"] == self.selected_id)
                record["created_at"] = old.get("created_at", record["created_at"])
                self.trips = [record if t["id"] == self.selected_id else t for t in self.trips]
                audit("TRIP_UPDATED")
            else:
                self.trips.append(record)
                audit("TRIP_CREATED")
            self.vault.save(self.trips)
            self.refresh()
            self.clear_form()
            messagebox.showinfo("Saved", "Trip saved securely.")
        except (ValueError, StopIteration) as e:
            messagebox.showerror("Check trip details", str(e))
        except SecurityError as e:
            messagebox.showerror("Secure storage error", str(e))

    def select_trip(self, _event=None):
        sel = self.tree.selection()
        if not sel: return
        self.selected_id = sel[0]
        t = next((x for x in self.trips if x["id"] == self.selected_id), None)
        if not t: return
        for k in self.vars: self.vars[k].set(str(t[k]))
        self.notes.delete("1.0", "end")
        self.notes.insert("1.0", t["notes"])

    def delete_trip(self):
        if not self.selected_id:
            messagebox.showwarning("Select a trip", "Select a trip from the list first.")
            return
        if not messagebox.askyesno("Confirm deletion", "Delete the selected trip permanently?"):
            return
        self.trips = [t for t in self.trips if t["id"] != self.selected_id]
        self.vault.save(self.trips)
        audit("TRIP_DELETED")
        self.clear_form()
        self.refresh()

    def export(self, kind):
        EXPORT_DIR.mkdir(exist_ok=True)
        suffix = {"csv": ".csv", "md": ".md", "txt": ".txt"}[kind]
        path = filedialog.asksaveasfilename(defaultextension=suffix,
                                            initialdir=EXPORT_DIR,
                                            filetypes=[("Report", "*" + suffix)])
        if not path: return
        {"csv": export_csv, "md": export_markdown, "txt": export_text}[kind](self.trips, path)
        audit("REPORT_EXPORTED_" + kind.upper())
        messagebox.showinfo("Export complete", f"Report saved to:\n{path}")

    def backup(self):
        BACKUP_DIR.mkdir(exist_ok=True)
        target = BACKUP_DIR / f"trips-{datetime.now().strftime('%Y%m%d-%H%M%S')}.vault"
        if VAULT_PATH.exists():
            shutil.copy2(VAULT_PATH, target)
            try: os.chmod(target, 0o600)
            except OSError: pass
            audit("ENCRYPTED_BACKUP_CREATED")
            messagebox.showinfo("Backup created", f"Encrypted backup saved:\n{target}")
        else:
            messagebox.showinfo("No data", "Save a trip first to create a backup.")

def login():
    DATA_DIR.mkdir(exist_ok=True)
    root = tk.Tk()
    root.title("Voyage | Secure Access")
    root.geometry("440x340")
    root.configure(bg=BG)
    root.resizable(False, False)
    box = tk.Frame(root, bg=PANEL, padx=30, pady=26)
    box.pack(fill="both", expand=True, padx=22, pady=22)
    tk.Label(box, text="✈  VOYAGE", bg=PANEL, fg=TEXT, font=("Segoe UI", 23, "bold")).pack(pady=(4, 4))
    tk.Label(box, text="YOUR TRAVEL DATA. YOUR CONTROL.", bg=PANEL, fg=MUTED,
             font=("Segoe UI", 8, "bold")).pack(pady=(0, 22))
    tk.Label(box, text="Master password", bg=PANEL, fg=TEXT, font=("Segoe UI", 10)).pack(anchor="w")
    password = tk.StringVar()
    entry = tk.Entry(box, textvariable=password, show="●", bg=PANEL2, fg=TEXT,
                     insertbackground=TEXT, relief="flat", font=("Segoe UI", 12))
    entry.pack(fill="x", ipady=10, pady=(6, 16))
    status = tk.Label(box, text="", bg=PANEL, fg=RED, font=("Segoe UI", 9))
    status.pack()
    state = {"vault": None}

    def unlock():
        try:
            state["vault"] = Vault(VAULT_PATH, password.get())
            audit("LOGIN_SUCCESS")
            root.destroy()
        except SecurityError as e:
            status.config(text=str(e))
            audit("LOGIN_FAILURE")
        except Exception:
            status.config(text="Unable to open secure storage.")
    tk.Button(box, text="UNLOCK SECURE WORKSPACE", command=unlock, bg=ACCENT, fg="#07111f",
              relief="flat", bd=0, padx=15, pady=11, font=("Segoe UI", 10, "bold")).pack(fill="x")
    tk.Label(box, text="First launch: create a strong password (12+ characters).",
             bg=PANEL, fg=MUTED, font=("Segoe UI", 8)).pack(pady=(16, 0))
    entry.focus()
    root.bind("<Return>", lambda _e: unlock())
    root.mainloop()
    if state["vault"]:
        main = tk.Tk()
        TravelApp(main, state["vault"])
        main.mainloop()

if __name__ == "__main__":
    login()
