import csv
from datetime import date
from pathlib import Path
from security import Vault, SecurityError
from app import validate_trip, DATA_DIR, VAULT_PATH, audit
from reports import export_csv, export_markdown, export_text

def ask(prompt, default=""):
    value = input(f"{prompt}" + (f" [{default}]" if default else "") + ": ").strip()
    return value or default

def show(trips):
    if not trips:
        print("\nNo trips found.")
        return
    print("\n" + "-" * 100)
    print(f"{'DESTINATION':22} {'DATES':25} {'CATEGORY':13} {'STATUS':12} {'COST (INR)':>14}")
    print("-" * 100)
    for t in trips:
        dates = f"{t['start_date']} → {t['end_date']}"
        print(f"{t['destination'][:22]:22} {dates:25} {t['category']:13} {t['status']:12} {t['cost']:14,.2f}")
    print("-" * 100)

def add_or_edit(trips, existing=None):
    print("\nEnter trip details (dates: YYYY-MM-DD). Leave a field blank to keep its current value when editing.")
    old = existing or {}
    data = {
        "destination": ask("Destination", old.get("destination", "")),
        "start_date": ask("Start date", old.get("start_date", date.today().isoformat())),
        "end_date": ask("End date", old.get("end_date", date.today().isoformat())),
        "cost": ask("Estimated cost INR", str(old.get("cost", "0"))),
        "category": ask("Category (Leisure/Business/Education/Family/Adventure/Other)", old.get("category", "Leisure")),
        "status": ask("Status (Planned/Ongoing/Completed/Cancelled)", old.get("status", "Planned")),
        "notes": ask("Notes", old.get("notes", "")),
    }
    record = validate_trip(data, old.get("id"), trips)
    if existing:
        record["created_at"] = old.get("created_at", record["created_at"])
        trips[:] = [record if t["id"] == old["id"] else t for t in trips]
        audit("CLI_TRIP_UPDATED")
    else:
        trips.append(record)
        audit("CLI_TRIP_CREATED")
    return trips

def main():
    DATA_DIR.mkdir(exist_ok=True)
    print("=" * 54)
    print("              VOYAGE - TRAVEL ORGANIZER")
    print("             Secure local itinerary vault")
    print("=" * 54)
    password = input("Master password (12+ characters): ")
    try:
        vault = Vault(VAULT_PATH, password)
        trips = vault.load()
    except SecurityError as e:
        print(f"\nSECURITY ERROR: {e}")
        return
    audit("CLI_LOGIN_SUCCESS")
    while True:
        print("""
1. View all trips
2. Add trip
3. Edit trip
4. Delete trip
5. Search trips
6. Filter by status
7. Executive summary
8. Import CSV
9. Export report
10. Save encrypted backup
0. Exit
""")
        choice = input("Choose an option: ").strip()
        try:
            if choice == "1":
                show(trips)
            elif choice == "2":
                add_or_edit(trips)
                vault.save(trips)
                print("Trip saved to encrypted vault.")
            elif choice in ("3", "4"):
                show(trips)
                trip_id = input("Enter exact trip ID: ").strip()
                found = next((t for t in trips if t["id"] == trip_id), None)
                if not found:
                    print("Trip ID not found.")
                elif choice == "3":
                    add_or_edit(trips, found)
                    vault.save(trips)
                    print("Trip updated.")
                elif input(f"Delete {found['destination']}? Type DELETE to confirm: ") == "DELETE":
                    trips.remove(found)
                    vault.save(trips)
                    audit("CLI_TRIP_DELETED")
                    print("Trip deleted.")
            elif choice == "5":
                q = input("Search destination, notes or category: ").strip().lower()
                show([t for t in trips if q and q in (t["destination"] + " " + t["notes"] + " " + t["category"]).lower()])
            elif choice == "6":
                status = input("Status (Planned/Ongoing/Completed/Cancelled): ").strip()
                show([t for t in trips if t["status"].lower() == status.lower()])
            elif choice == "7":
                active = [t for t in trips if t["status"] != "Cancelled"]
                total = sum(t["cost"] for t in active)
                print(f"\nTotal trips: {len(trips)}")
                print(f"Planned: {sum(t['status']=='Planned' for t in trips)}")
                print(f"Ongoing: {sum(t['status']=='Ongoing' for t in trips)}")
                print(f"Completed: {sum(t['status']=='Completed' for t in trips)}")
                print(f"Estimated active budget: INR {total:,.2f}")
                print(f"Average active trip cost: INR {(total/len(active) if active else 0):,.2f}")
            elif choice == "8":
                path = Path(input("CSV file path: ").strip()).expanduser()
                added, errors = 0, []
                with path.open(newline="", encoding="utf-8-sig") as f:
                    reader = csv.DictReader(f)
                    for line, row in enumerate(reader, 2):
                        try:
                            rec = validate_trip(row)
                            trips.append(rec)
                            added += 1
                        except Exception as e:
                            errors.append(f"Row {line}: {e}")
                vault.save(trips)
                print(f"Imported {added} row(s); rejected {len(errors)}.")
                for err in errors[:20]: print(" - " + err)
            elif choice == "9":
                kind = input("Format (csv/md/txt): ").strip().lower()
                if kind not in ("csv", "md", "txt"):
                    print("Unsupported format.")
                else:
                    path = input("Output file path: ").strip()
                    {"csv": export_csv, "md": export_markdown, "txt": export_text}[kind](trips, path)
                    audit("CLI_REPORT_EXPORTED")
                    print(f"Report exported: {path}")
            elif choice == "10":
                import shutil, os
                from datetime import datetime
                from app import BACKUP_DIR
                BACKUP_DIR.mkdir(exist_ok=True)
                target = BACKUP_DIR / f"trips-{datetime.now():%Y%m%d-%H%M%S}.vault"
                if VAULT_PATH.exists():
                    shutil.copy2(VAULT_PATH, target)
                    try: os.chmod(target, 0o600)
                    except OSError: pass
                    print(f"Encrypted backup created: {target}")
                else:
                    print("No vault to back up yet.")
            elif choice == "0":
                print("Your encrypted vault is saved. Goodbye.")
                break
            else:
                print("Choose a valid menu option.")
        except (ValueError, OSError, KeyError) as e:
            print(f"Input or file error: {e}")
        except SecurityError as e:
            print(f"Secure storage error: {e}")

if __name__ == "__main__":
    main()
